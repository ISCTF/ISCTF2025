#!/usr/bin/env python3
# gen_payload.py -- 用于生成 payload.dat 的脚本（裁判专用）
FLAG = 'ISCTF{Y0u_a2e_2ea11y_a_1aby2inth_master}'

def rc4_variant(data: bytes, key: bytes) -> bytes:
    # 变种 RC4：KSA 中加入基于索引的小扰动
    S = list(range(256))
    j = 0
    keylen = len(key)
    for i in range(256):
        j = (j + S[i] + key[i % keylen] + (i & 0xAA)) & 0xFF
        S[i], S[j] = S[j], S[i]
    i = j = 0
    out = bytearray()
    for byte in data:
        i = (i + 1) & 0xFF
        j = (j + S[i]) & 0xFF
        S[i], S[j] = S[j], S[i]
        K = S[(S[i] + S[j]) & 0xFF]
        out.append(byte ^ K)
    return bytes(out)

def xor_cycle(data: bytes, key: bytes) -> bytes:
    return bytes([b ^ key[i % len(key)] for i, b in enumerate(data)])

def build_payload(flag_str: str) -> bytes:
    b = flag_str.encode('utf-8')
    xor_key = b'P4ssXOR'       # 裁判/生成器使用的 XOR Key（不要放给选手）
    rc4_key = b'Secr3tK3y!'    # 裁判/生成器使用的 RC4 Key（不要放给选手）
    # 加密流程：先 XOR 再 RC4 变种
    x = xor_cycle(b, xor_key)
    c = rc4_variant(x, rc4_key)
    return c

if __name__ == '__main__':
    payload = build_payload(FLAG)
    with open('payload.dat', 'wb') as f:
        f.write(payload)
    print('payload.dat 已生成（包含加密后的 flag）')