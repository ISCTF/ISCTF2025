#!/bin/bash

# 切换到工作目录
cd /pwn

# 设置flag（如果需要）
if [ ! -z $FLAG ]
then
    if [ "$(cat ./flag)" != "$FLAG" ]
    then
        echo $FLAG > ./flag

        if [ $? -eq 0 ]; then
            echo "成功替换 flag"
        else
            echo "处理失败"
        fi
    fi
fi

echo "Starting pwn challenge..."

# 检查pwn文件是否存在
if [ ! -f "/pwn/pwn" ]; then
    echo "Error: /pwn/pwn not found!"
    exit 1
fi

# 检查pwn文件是否可执行
if [ ! -x "/pwn/pwn" ]; then
    echo "Error: /pwn/pwn is not executable!"
    exit 1
fi

# 使用socat监听端口并运行pwn二进制文件
exec socat TCP-LISTEN:1337,reuseaddr,fork EXEC:"/pwn/pwn",stderr