#!/bin/sh
# Add your startup script
#!/bin/sh
sed -i "s/GWHT{test}/$FLAG/" /home/ctf/flag
export FLAG=""
# DO NOT DELETE
/etc/init.d/xinetd start;
sleep infinity;
