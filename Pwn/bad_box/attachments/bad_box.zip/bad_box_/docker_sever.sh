#!/bin/sh
cat <<-EOF > /etc/docker/daemon.json 
{
  "registry-mirrors": [
  	"https://docker.xuanyuan.me"
  	]
}
EOF
systemctl daemon-reload
systemctl restart docker
