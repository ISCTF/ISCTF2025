#!/bin/sh
user=$(ls /home)

# Check for various flag environment variables and use the first one that is set
if [ -n "$DASFLAG" ]; then
    INSERT_FLAG="$DASFLAG"
elif [ -n "$FLAG" ]; then
    INSERT_FLAG="$FLAG"
elif [ -n "$GZCTF_FLAG" ]; then
    INSERT_FLAG="$GZCTF_FLAG"
else
    INSERT_FLAG="flag(TEST_Dynamic_FLAG)"
fi

# Write the flag to both files
echo "$INSERT_FLAG" > /home/$user/flag

# 赋予程序运行权限 (注意: 您的目录里没有 attachment，可以注释或删除这行)
# chmod 711 /home/ctf/attachment

# /etc/init.d/xinetd start;
/bin/xinetd -f /etc/ctf.xinetd -pidfile /run/xinetd.pid -limit 1000 -reuse;
sleep infinity;