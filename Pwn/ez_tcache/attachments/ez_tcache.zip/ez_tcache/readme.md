# 说明

使用`alpine + xinetd + chroot +patchelf` 部署`pwn`题

- 参照模板，将二进制文件放置在`./bin`目录下
- 参照模板，将运行所需的`glibc`文件放置在`./glibc`目录下
- `run_pwn.sh`中可以放置`proof of work`代码或者设置`timeout`时间
- 运行`./build_image.sh`可以生成镜像以及提供给选手的`attachment`文件夹

![image-20250915101248727](image-20250915101248727.png)

- 在`./deploy/docker-compose.yaml`文件中修改映射的宿主机端口、`flag`的内容
- 其他需求可自行根据模板文件定制

# 本地测试

在deploy目录下执行`./build_image.sh`构建镜像

在本地可以通过`nc 127.0.0.1 10001`来测试

运行测试exp，通过`./exp.py G`或`python3 exp.py G`来测试docker启动的容器

最终效果如下：

![image-20250915101337495](image-20250915101337495.png)
