#!/usr/bin/env python3
import sys
assert sys.stdout.isatty()

flag = open("/flag.txt").read().strip()
to_print = flag + '\r' + ("""  ___ ____   ____ _____ _____ 
 |_ _/ ___| / ___|_   _|  ___|
  | |\___ \| |     | | | |_   
  | | ___) | |___  | | |  _|  
 |___|____/ \____| |_| |_|    
""")
print(to_print)