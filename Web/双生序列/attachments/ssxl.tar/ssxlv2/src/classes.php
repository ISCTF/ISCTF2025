<?php
class Cat {
    public function OwO(...$args) {
        return "喵喵喵~";
    }

    public function __destruct() {
        $this->OwO();
    }

    public static function __callStatic($name, $args) {
        $cat = new self();
        return $cat->OwO($name, $args);
    }

    public function __autoload($class) {
        return $this->OwO();
    }

    public function __debugInfo() {
        return [
            "OwO" => $this->OwO(),
            "version" => "0.7.3",
            "php" => "php 8.2",
            "engine" => "apache",
        ];
    }
}

class Writer {
    public $b64data = "";
    private $binfile = "/tmp/ssxl/write.bin";
    private $metafile = "/tmp/ssxl/write.meta";
    private $secret = "kaqikaqi";
    public $init = '喵喵喵?';

    public function __construct($b64data="") {
        $this->b64data = $b64data;
    }

    public function __wakeup() {
        $this->{$this->init}();
    }

    private function init() {
        $dir = dirname($this->binfile);
        if (!is_dir($dir)) {
            @mkdir($dir, 0700, true);
        }
    }

    private function write_all() {
        if ($this->b64data === "") {
            return;
        }

        $raw = base64_decode($this->b64data);
        if ($raw === false) {
            return;
        }

        @file_put_contents($this->binfile, $raw);

        $sig = hash_hmac("sha256", $raw, $this->secret);
        $meta = json_encode([
            "sig" => $sig,
            "ts"  => time(),
        ]);
        @file_put_contents($this->metafile, $meta);
    }

    public function fetch() {
        $this->write_all();
        return "喵喵喵!";
    }
}

class Shark {
    public $ser = "";

    public function __construct($s="") {
        $this->ser = $s;
    }

    public function __toString() {
        $this->apply();
        return "喵喵喵!";
    }

    private function apply() {
        if ($this->ser === "") {
            return;
        }

        $file = "/tmp/ssxl/run.bin";
        @file_put_contents($file, $this->ser);
    }

    public function fetch() {
        return "喵喵喵!";
    }
}

class Pytools extends Cat {
    public $log = False;
    private $logbuf = "看看你都干了什么好事喵！<br/>";

    public function run() {
        $cmd = "python3 /var/www/html/pytools.py";
        $out = @shell_exec($cmd . " 2>&1");
        $this->log = $out;
        return $out;
    }

    public function __call($name, $args) {
        return $this->run();
    }

    public function __destruct() {
        if ($this->logbuf) {
            echo $this->logbuf;
            return $this->logbuf;
        }
    }

    public function get_info() {
        if ($this->log) {
            $this->logbuf = $this->logbuf . "\n" . $this->log;
        }
    }
}

class Bridge {
    public $writer;   
    public $shark;

    public function __construct($w, $s) {
        if (!($w instanceof Writer) || !($s instanceof Shark)) {
            echo "喵喵喵?";
            exit(1);
        }
        $this->writer = $w;
        $this->shark = $s;
    }

    public function __get($name) {
        if ($name === "write") {
            if (!($this->writer instanceof Writer)){
                return "喵喵喵?";
            }
            
            $this->writer->fetch();
            return $this->shark;
        }
    }

    public function __isset($name) {
        if ($name === "write") {
            return
                ($this->writer instanceof Writer) &&
                ($this->shark instanceof Shark);
        }
        return false;
    }

    public function __set($name, $value) {
        if ($name === "write") {
            $this->writer = $value;
        }
        else if ($name === "shark") {
            $this->shark = $value;
        }
    }

    public function __unset($name) {
        if ($name === "write") {
            $this->writer = null;
        }
        else if ($name === "shark") {
            $this->shark = null;
        }
    }

    public function fetch() {
        $next = $this->write;
        if ($next instanceof Shark) {
            return $next;
        }
        return "喵喵喵!";
    }
}

class Bash {
    public $cmd = "ls";
    private $cmds = ["ls", "id", "pwd"];
    private $path = "/var/www/html/";

    public function __construct($cmd="", $path="") {
        $this->cmd = $cmd;
    }

    public function __invoke() {
        $c = strtolower($this->cmd);
        if (!in_array($c, $this->cmds)) {
            return "喵喵喵?";
        }
        return shell_exec($c);
    }

    public function __toString() {
        return $this();
    }
}



?>
