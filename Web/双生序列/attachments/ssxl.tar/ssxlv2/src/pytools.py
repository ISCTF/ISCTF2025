import os
import pickle
import json
import hmac
import hashlib
import time
import random
import time
import sys
import io

class RCE:
    def __reduce__(self):
        return (os.system, ("cat /etc/passwd",))

class Set:
    def __init__(self):
        self.secret = b""
        self.payload = b""

    def __setstate__(self, state):
        self.secret = state.get("secret", b"")
        self.payload = state.get("payload", b"")

class Unpickler(pickle.Unpickler):
    allows = {
        ("__main__", "Set")
    }

    def find_class(self, module, name):
        if (module, name) in self.allows:
            return super().find_class(module, name)
        raise pickle.UnpicklingError("喵喵喵?")

class ssxl:
    def __init__(self):
        self.ROOT = "/tmp/ssxl"
        self.BIN = f"{self.ROOT}/write.bin"
        self.META = f"{self.ROOT}/write.meta"
        self.OUTS = f"{self.ROOT}/outs.txt"
        self.SECRET = b""
        self.jmp = True   # 你能设置这个吗😋

    def _set_secret(self, data):
        bio = io.BytesIO(data)
        obj = Unpickler(bio).load()
        
        if not isinstance(obj, Set):
            Games().gen_redirect()
            return "喵喵喵?"

        if isinstance(getattr(obj, "secret", b""), (bytes, bytearray)):
            self.SECRET = obj.secret

        return obj

    def init(self):
        r = 0
        if not os.path.exists(self.ROOT):
            print("==> no ROOT")
            r = 1
        if not os.path.exists(self.BIN):
            print("==> no BIN")
            r = 1
        if not os.path.exists(self.META):
            print("==> no META")
            r = 1
        return r == 0

    def load_bin(self):
        with open(self.BIN, "rb") as bf:
            return bf.read()

    def load_meta(self):
        with open(self.META, "r", encoding="utf-8", errors="ignore") as jf:
            return json.load(jf)

    def sig_check(self, meta, data):
        sig = meta.get("sig")
        ts = meta.get("ts")
        calc = hmac.new(self.SECRET, data, hashlib.sha256).hexdigest()

        if not isinstance(sig, str) or not hmac.compare_digest(sig, calc):
            print("==> sig check failed")
            return False

        if ts and (time.time() - float(ts) > 600):
            print("==> ts check failed")
            return False

        return True

    def read_out(self):
        if not os.path.exists(self.OUTS):
            raise FileNotFoundError(self.OUTS)
        with open(self.OUTS, "r", encoding="utf-8", errors="ignore") as of:
            content = of.read()
        return content or "喵喵喵?"

    def run(self):
        assert self.init()
        data = self.load_bin()

        try:
            obj = self._set_secret(data)
        except Exception as e:
            print("==> pickle load failed\n", e)
            if self.jmp:
                Games().gen_redirect()
            return

        meta = self.load_meta()
        assert self.sig_check(meta, data)

        print("==> obj => ", obj)

        payload = getattr(obj, 'payload', None)

        open(self.OUTS, "w").close()

        if isinstance(payload, (bytes, bytearray)):
            try:
                inner = pickle.loads(payload)
            except Exception as e:
                print("==> inner pickle load failed\n", e)
                if self.jmp:
                    Games().gen_redirect()
                return

        try:
            out = self.read_out()
        except Exception as e:
            print("==> no outs =>\n", e)
            if self.jmp:
                Games().gen_redirect()
            return

        print("==> out => ", out)


class ret2game(Exception):
    def __init__(self, url):
        super().__init__()
        self.url = url
    
    def __str__(self):
        r = 'Redirect to: ' + self.url
        return r

    def to_html(self):
        template = f'''
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>喵喵喵……</title>
        <script>
            location.replace("{self.url}");
        </script>
        <style>
            body{{font-family:system-ui;padding:24px}}
        </style>
    </head>
    <body>
        <p>恭喜你抽到：<a href="{self.url}">{self.url}</a></p>
    </body>
</html>
        '''
        return template

class Games:
    def __init__(self):
        urls = {
            "isctf": "https://isctf2025.bluesharkinfo.com/",
            "blueshark": "https://www.bluesharkinfo.com/",
            "yuanshen": "https://ys.mihoyo.com/main/",
            "bengtie": "https://sr.mihoyo.com/main",
            "sanguosha": "https://www.sanguosha.com/",
            "huoying": "https://hyrz.qq.com/main.shtml",
            "diwurenge": "https://id5.163.com/",
            "mingchao": "https://mc.kurogames.com/main",
            "wzry": "https://pvp.qq.com/",
            "sanjiaozhou": "https://df.qq.com/main.shtml",
            "wuweiqiyue": "https://val.qq.com/main.html",
            "dota2": "https://www.dota2.com.cn/",
            "lol": "https://lol.qq.com/main.shtml"
        }
        self.urls = list(urls.values())
        self.weights = [5, 3] + [1] * (len(urls) - 2)

    def gen_url(self):
        url = random.choices(self.urls, weights=self.weights, k=1)[0]
        return url

    def gen_redirect(self):
        url = self.gen_url()
        raise ret2game(url)

try:
    challenge = ssxl()
    challenge.run()
except ret2game as e:
    sys.stdout.write(e.to_html())
    sys.stdout.flush()

