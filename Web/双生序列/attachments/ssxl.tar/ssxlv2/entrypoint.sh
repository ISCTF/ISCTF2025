#!/bin/bash

set -euo pipefail

HEX=$(head -c 16 /dev/urandom | xxd -p)
FLAG="ISCTF{Oh_Y0u_Did_1t!___this_is_your_flag_${HEX}}"

echo -n "${FLAG}" > /flag
chown www-data:www-data /flag
chmod 400 /flag
chmod 555 -R /var/www/html

mkdir -p /tmp/ssxl
chown www-data:www-data /tmp/ssxl

echo $FLAG
echo "==> run done"

exec "$@"


