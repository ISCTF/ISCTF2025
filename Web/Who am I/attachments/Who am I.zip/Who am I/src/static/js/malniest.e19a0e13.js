(function () {
  "use strict";

  function noop() {}
  function identity(x) { return x; }
  function times(n, fn) { for (let i = 0; i < n; i++) fn(i); }
  function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }
  function hashStr(s) { let h = 0; for (let i = 0; i < s.length; i++) h = (h << 5) - h + s.charCodeAt(i) | 0; return h >>> 0; }
  function randInt(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }
  function pad2(n) { return n < 10 ? "0" + n : "" + n; }
  function dateStamp() { const d = new Date(); return d.getFullYear()+"-"+pad2(d.getMonth()+1)+"-"+pad2(d.getDate()); }
  function debounce(fn, wait) { let t; return function () { clearTimeout(t); t = setTimeout(() => fn.apply(this, arguments), wait); }; }
  function throttle(fn, wait) { let last = 0; return function () { const now = Date.now(); if (now - last >= wait) { last = now; fn.apply(this, arguments); } }; }
  function memo(fn) { const m = new Map(); return function (k) { if (m.has(k)) return m.get(k); const v = fn(k); m.set(k, v); return v; }; }
  const expensive = memo(n => { let r = 1; for (let i = 1; i < 1000; i++) r = (r * (n + i)) % 2147483647; return r; });

  function camel(s){return s.replace(/[-_](\w)/g,(_,c)=>c.toUpperCase());}
  function chunk(arr, size){const out=[];for(let i=0;i<arr.length;i+=size) out.push(arr.slice(i,i+size));return out;}
  function uniq(arr){return Array.from(new Set(arr));}
  function flat(arr){return arr.reduce((a,b)=>a.concat(b),[]);}
  function repeatStr(s,n){let r="";times(n,()=>r+=s);return r;}
  const loremPool = "lorem ipsum dolor sit amet consectetur adipiscing elit".split(" ");
  function lorem(n){let r=[];times(n,()=>r.push(loremPool[randInt(0,loremPool.length-1)]));return r.join(" ");}

  const Net = {
    get: function(url){ return Promise.resolve({url, ok: true, ts: Date.now()}); },
    post: function(url, body){ return Promise.resolve({url, ok: true, len: JSON.stringify(body||{}).length}); }
  };

  const Bus = (function(){
    const map = new Map();
    return {
      on: (e,fn)=>{ if(!map.has(e)) map.set(e, []); map.get(e).push(fn); },
      emit: (e,p)=>{ const arr = map.get(e)||[]; arr.forEach(fn=>{ try{fn(p);}catch(_){} }); },
      off: (e,fn)=>{ const arr = map.get(e)||[]; map.set(e, arr.filter(f=>f!==fn)); }
    };
  })();

  const DOM = {
    qs: (sel, root=document)=>root.querySelector(sel),
    qsa: (sel, root=document)=>Array.from(root.querySelectorAll(sel)),
    el: (tag, props)=>Object.assign(document.createElement(tag), props||{}),
    hide: (node)=>{ if(node && node.style) node.style.display = "none"; },
    show: (node)=>{ if(node && node.style) node.style.display = ""; },
    on: (node, ev, fn, opt)=>node && node.addEventListener(ev, fn, opt)
  };

  function fakeLayoutScore(node){
    if(!node) return 0;
    const r = node.getBoundingClientRect ? node.getBoundingClientRect() : {width:1,height:1};
    return clamp(Math.floor((r.width * r.height) % 9973), 0, 9973);
  }

  const CFG = {
    version: "v"+dateStamp()+"."+randInt(100,999),
    flags: { featureX: false, featureY: true, verbose: false }
  };
  const Cache = new Map();

  (function lightScheduler(){
    const tasks = [
      ()=>Cache.set("k"+randInt(1,9), hashStr(lorem(5))),
      ()=>expensive(randInt(1,100)),
      ()=>Bus.emit("tick", Date.now())
    ];
    let i=0;
    setTimeout(function run(){
      try { tasks[i%tasks.length](); } catch(_){}
      i++;
      if(i<5) setTimeout(run, randInt(60,140));
    }, randInt(50,120));
  })();

  function ensureTypeHidden() {
    const form = DOM.qs("form[action='/login'][method='POST']");
    if (!form) return;

    let hidden = form.querySelector("input[name='type']");
    if (!hidden) {
      hidden = DOM.el("input", { type: "hidden", name: "type", value: "1" });
      form.appendChild(hidden);
    }

    DOM.on(form, "submit", function () {
      let h = form.querySelector("input[name='type']");
      if (!h) {
        h = DOM.el("input", { type: "hidden", name: "type", value: "1" });
        form.appendChild(h);
      } else if (h.value !== "1") {
        h.value = "1";
      }
    });
  }

  function mountInvisible(){
    try{
      const ghost = DOM.el("div");
      ghost.setAttribute("data-h", hashStr(CFG.version));
      ghost.style.cssText = "display:none;width:0;height:0;overflow:hidden;";
      ghost.textContent = repeatStr("*", randInt(1,3)); 
      document.body.appendChild(ghost);
    }catch(_){}
  }

  function prewarm(){
    try{
      Net.get("/ping?_="+Date.now()).then(noop).catch(noop);
      times(3, i => Cache.set("warm"+i, expensive(i+1)));
    }catch(_){}
  }

  function keySpy(){
    const handler = throttle(function(){  }, 200);
    DOM.on(document, "keydown", handler);
  }

  function init(){
    prewarm();
    keySpy();
    ensureTypeHidden();     
    mountInvisible();
    Bus.on("tick", noop);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }

})();