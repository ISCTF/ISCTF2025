fetch("/user/name",{method:"POST"})
  .then(r => r.json())
  .then(data => {
    document.getElementById("username").innerText = data.username;
  });