# Who am I

## 环境说明

提供 `Python 3.10 + Flask + pydash` 的基础环境，默认暴露端口位于8080

## 如何使用

可以直接构建镜像

```
docker build .
```

之后启动容器



也可以直接使用 `./docker/docker-compose.yml` 内的 `docker-compose` 文件实现一键启动容器

```shell
cd ./docker
docker-compose up -d
```