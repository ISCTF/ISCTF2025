from flask import Flask, request, render_template_string, send_file
import os
import shutil
import tarfile

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = "./uploads"
app.config["MAX_CONTENT_LENGTH"] = 100 * 1024
ALLOWED_EXTENSIONS = set(["tar", "png", "avif", "webp", "gif", "jxl"])

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>理工生的同人文件分享站</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            line-height: 1.6;
            color: #333;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #ddd;
        }

        .upload-section {
            margin-bottom: 20px;
            padding: 15px;
            border: 1px solid #ddd;
        }

        .file-input {
            margin: 10px 0;
            width: 100%;
            padding: 8px;
        }

        .submit-btn {
            padding: 8px 16px;
            background-color: #f0f0f0;
            border: 1px solid #ccc;
            cursor: pointer;
        }

        .message {
            padding: 10px;
            margin: 10px 0;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
        }

        .file-list {
            margin-top: 20px;
            padding: 15px;
            border: 1px solid #ddd;
        }

        .file-item {
            padding: 5px 0;
        }

        .clean-link {
            display: block;
            margin-top: 20px;
            padding: 10px;
            text-align: center;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            color: #333;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">
            <h1>理工生的同人文件分享站</h1>
            <p>这是我用业余时间用Python+Flask写的一个分享网站，希望你喜欢</p>
            <p>支持上传.png .avif .webp .gif .jxl .txt文件</p>
            <p>同时本站还支持上传打包格式，上传后会自动帮你解压到目录.</p>
            <p>作为理工生，<b>打包格式用tar不过分吧</b></p>
        </div>

        <div class="upload-section">
            <h3>上传文件</h3>
            <form method="POST" enctype="multipart/form-data">
                <input type="file" name="file" accept=".tar, .png, .avif, .webp, .gif, .jxl, .txt" class="file-input"
                    required>
                <input type="submit" value="上传" class="submit-btn">
            </form>
        </div>

        {% if message %}
        <div class="message">
            {{ message }}
        </div>
        {% endif %}

        <div class="file-list">
            <h3>文件列表</h3>
            <ul>
                {% for file in files %}
                <li class="file-item">
                    <a href="/download/{{ file }}">{{ file }}</a>
                </li>
                {% else %}
                <li>暂无文件</li>
                {% endfor %}
            </ul>
        </div>

        <a href="/clean" class="clean-link">清理上传目录</a>
    </div>
</body>

</html>
"""


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route("/")
def index():
    files = (
        os.listdir(app.config["UPLOAD_FOLDER"])
        if os.path.exists(app.config["UPLOAD_FOLDER"])
        else []
    )
    return render_template_string(HTML_TEMPLATE, files=files)


@app.route("/", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return render_template_string(HTML_TEMPLATE, message="请选择文件", files=[])

    file = request.files["file"]
    if file.filename == "":
        return render_template_string(HTML_TEMPLATE, message="请选择文件", files=[])

    if (
        file
        and allowed_file(file.filename)
        and ".." not in file.filename
        and "/" not in file.filename
    ):
        os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

        file_save_path = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
        if os.path.exists(file_save_path):
            return render_template_string(HTML_TEMPLATE, message="文件已存在", files=[])

        file.save(file_save_path)
        if file.filename.endswith(".tar"):
            try:
                with tarfile.open(file_save_path, "r") as tf:
                    tf.extractall(app.config["UPLOAD_FOLDER"])
                os.remove(file_save_path)  # 解压后删除原始tar
            except Exception as e:
                return render_template_string(
                    HTML_TEMPLATE, message=f"解压失败: {str(e)}", files=[]
                )

    else:
        return render_template_string(
            HTML_TEMPLATE,
            message="只支持TAR、PNG、AVIF、WEBP、GIF、JXL、TXT文件",
            files=[],
        )

    files = os.listdir(app.config["UPLOAD_FOLDER"])
    return render_template_string(HTML_TEMPLATE, message="上传成功！", files=files)


@app.route("/download/<filename>")
def download_file(filename):
    if filename is None or filename == "":
        return "文件名不能为空"

    if ".." in filename or "/" in filename:
        return "欸，不能欺骗人家呀"

    filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)

    if not os.path.exists(filepath) or not os.path.isfile(filepath):
        return "文件不存在"

    try:
        return send_file(filepath, as_attachment=False)
    except Exception as e:
        return f"读取文件失败: {str(e)}"


@app.route("/clean")
def clean():
    # 清理上传目录
    if os.path.exists(app.config["UPLOAD_FOLDER"]):
        shutil.rmtree(app.config["UPLOAD_FOLDER"])
    os.makedirs(app.config["UPLOAD_FOLDER"])
    return "清理完成"


if __name__ == "__main__":
    if os.path.exists(app.config["UPLOAD_FOLDER"]):
        shutil.rmtree(app.config["UPLOAD_FOLDER"])
    os.makedirs(app.config["UPLOAD_FOLDER"])
    app.run(host="0.0.0.0", port=8080, debug=True)
