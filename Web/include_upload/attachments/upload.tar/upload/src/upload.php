
<?php
error_reporting(0);
header("Content-type:text/html;charset=utf-8"); 
 //白名单 
 $ext_arr = array('png');
 $file_ext = substr($_FILES['file']['name'],strrpos($_FILES['file']['name'],".")+1);
 //判断filename是否为空
 $file = empty($_POST['filename']) ? $_FILES['file']['name'] : $_POST['filename'];
 //判断filename的后缀是不是在黑名单
 $name = basename($_POST['filename']);
 $filename_ext= pathinfo($name,PATHINFO_EXTENSION);
 $filename=$_FILES['file']['name'];
 $content = file_get_contents($_FILES['file']['tmp_name']);

if(in_array($file_ext,$ext_arr)){
    //检测文件后缀
    echo "后缀没错"."\n";
       //整个文件内容检测
       if (stripos($content, '<?') === false && stripos($content, 'php') === false) {
                if (file_exists("upload/" . $_FILES["file"]["name"]))
                {
                        echo $_FILES["file"]["name"] . " 文件已经存在。 ";
                }
                else
                {
                        // 如果 upload 目录不存在该文件则将文件上传到 upload 目录下
                        move_uploaded_file($_FILES["file"]["tmp_name"], "upload/" . $_FILES["file"]["name"]);
                        echo "文件存储在: " . "upload/" . $filename;
                }
        }
        else{
            echo "别看了，我这waf你过不掉的，看看这题的特点，看看提示也行"."\n";

        }
    }
else{
        echo "必须上传.png哦";
    }


?>

