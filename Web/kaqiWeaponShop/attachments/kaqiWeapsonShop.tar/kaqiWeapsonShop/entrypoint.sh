#!/bin/bash

set -euo pipefail

HEX=$(head -c 16 /dev/urandom | xxd -p)
FLAG="ISCTF{${HEX}}"

export FLAG

echo "${FLAG}"
echo "==> run done"

python3 /app/app.py
