# author by bx∮kaqi
import os
import re
import random
import flask
import sqlite3
import uuid

from urllib3 import response

# 路径
app = flask.Flask(__name__)
base_dir = os.getcwd()

# 数据库
db_name = 'weapon.db'
weapon_db = os.path.join(base_dir, db_name)

# 主页面
index_page = 'index.html'

# 首次初始化标志位
db_inited = False

# 要写入数据库的内容
weapons = [
    (1, '杖1', './static/1.jpg'),
    (2, '剑1', './static/2.jpg'),
    (3, '刀1', './static/3.jpg'),
    (4, '刀2', './static/4.jpg'),
    (5, '弓1', './static/5.jpg'),
    (6, '弓2', './static/6.jpg'),
    (7, '枪1', './static/7.jpg'),
    (8, '枪2', './static/8.jpg'),
]

def connect(db):
    '''
    连接数据库
    :param db: 数据库文件路径
    :return: sqlite3.connect
    '''
    conn = sqlite3.connect(db)
    return conn

def create_table(curs, sql):
    '''
    建表
    :param curs: conn.cursor
    :param sql: 创建表的语句
    :return bool: 成功或失败
    '''
    try:
        curs.execute(sql)
    except Exception:
        return False
    return True

def table_count(curs, table_name):
    '''
    返回表的行数
    :param curs: conn.cursor
    :param table_name: 表名
    :return int: 行数，发生异常则返回 0
    '''
    sql = 'SELECT count(0) FROM ' + table_name
    curs.execute(sql)
    row = curs.fetchone()
    if row is not None:
        return row[0]
    return 0

def create_table_weapons(curs):
    '''
    创建题目所需的 weapons 表
    :return bool: 成功或失败
    '''
    sql = '''
        create table if not exists weapons (
            id integer primary key,
            name text not null,
            image text not null
        )
    '''
    r = create_table(curs, sql)
    if not r:
        print(f'==> create_table_weapons')
        return False
    return True

def create_table_flag(curs):
    '''
    创建题目的 flag 表
    :return bool: 成功后失败
    '''
    sql = '''
        create table if not exists flag (
            flag text not null
        )
    '''
    r =  create_table(curs, sql)
    if not r:
        print(f'==> create_table_flag')
        return False
    return True

def insert_weapons(curs):
    '''
    向 weapons 表写入 weapons 数据
    :param curs: conn.cursor
    :return bool: 成功或失败
    '''
    table_name = 'weapons'
    count = table_count(curs, table_name)

    sql = '''
        INSERT INTO weapons (
            id,
            name,
            image
        ) VALUES (
            ?,
            ?,
            ?
        )
    '''

    if count == 0:
        try:
            curs.executemany(sql, weapons)

            print(f'==> insert_weapons')
            return True

        except Exception:
            return False
    return False

def gen_flag():
    '''
    补丁：waf 拦截连续 8 位以上数字，所以 flag 要避免这种情况
    '''
    pat = re.compile(r'\d{8,}')
    c = 1
    while True:
        print(f'flag generator count ==> {c}')
        s = uuid.uuid4().hex
        if not pat.search(s):
            return s
        c += 1

def insert_flag(curs):
    '''
    向 flag 表写入 flag 数据
    :param curs: conn.cursor
    :return bool: 成功或失败
    '''
    table_name = 'flag'
    count = table_count(curs, table_name)

    sql = '''
        INSERT INTO flag (
            flag
        ) VALUES (
            ?
        )
    '''

    if count == 0:
        try:
            _flag = os.environ.get('FLAG')
            if not _flag:
                _flag = f'flag{{{gen_flag()}}}'

            curs.execute(sql, (_flag, ))

            print(f'==> insert_flag')
            return True

        except Exception:
            return False
    return False

def init_db(db_name):
    conn = connect(db=db_name)
    curs = conn.cursor()
    create_table_weapons(curs)
    create_table_flag(curs)
    insert_weapons(curs)
    insert_flag(curs)
    conn.commit()
    conn.close()

def waf():
    black_list = [
        # 注释
        r';',
        r'--',
        r'#',
        r'/\*',
        r'\*/',

        # 通配
        r'\|\|',
        r'[%_]',

        # 管理操作
        r'\bunion\b',
        r'\binsert\b',
        r'\bupdate\b',
        r'\bdelete\b',
        r'\bdrop\b',
        r'\balter\b',
        r'\battach\b',
        r'\bpragma\b',
        r'\bload_extension\b',
        r'\bsqlite_master\b',

        # 字符构造
        r'\bhex\b',
        r'\bunhex\b',
        r'\bunicode\b',
        r'\bchar\b',

        # 字符串操作
        r'\bsubstr\b',
        r'\bsubstring\b',
        r'\bprintf\b',
        r'\bformat\b',
        r'\bquote\b',

        # 资源攻击探测
        r'\b\d{8,}\b',
        r'\brandomblob\b',
        r'\bzeroblob\b',
        # r'\brandom\b',
        r'\bwith\s+recursive\b',

        # +字符串操作
        # r'\blength\b',
        r'\blike\b',
        r'\bglob\b',
        r'\binstr\b',

        # 条件判断
        # r'\bcase\b',
        # r'\bwhen\b',
        # r'\bthen\b',
        # r'\belse\b',
        # r'\bend\b',

        # 聚合分组
        r'\bcount\b',
        r'\bsum\b',
        r'\bavg\b',
        r'\bgroup\s+by\b',
        r'\bhaving\b',

        # 排序规则
        r'\bcollate\b',
        r'\bnocase\b',

        # 大小写
        r'\bupper\b',
        r'\blower\b',
        r'\breplace\b',

        # 区间匹配
        r'\bbetween\b',
        r'\bregexp\b',
    ]
    return re.compile('|'.join(black_list), re.I | re.S | re.U)

def waf_check(text):
    '''
    检查从 html 传过来的值

    检查项
        内容长度
        不可见字符
        WAF 检测

    :return bool: 成功通过、失败拦截

    补丁：增加 return x, tip 提示拦截位置
    '''
    if text is None:
        return True, None

    # 长度限制，不给超长 payload 枚举
    if len(text) > 200:
        return False, 'len(text) > 200'

    # 不可见字符
    for ch in text:
        if ord(ch) < 32:
            return False, 'control-char'

    # waf 检测
    w = waf()
    m = w.search(text)
    if m:
        return False, f'{m.group(0)}'

    return True, None

def select_rows(sql, params, db):
    '''
    查询用的

    :param sql: 带符号 ? 的 sql 查询语句
    :param params: tuple 类型的参数
    :param db: 要查询的数据库
    :return: 行字典 fetchall
    '''
    conn = connect(db)
    conn.row_factory = sqlite3.Row
    curs = conn.cursor()
    curs.execute(sql, params)
    rows = curs.fetchall()
    conn.close()
    return rows

def error(msg, code=400):
    '''
    用来返回错误页面

    :param msg: 页面显示的内容
    :param code: http 状态码
    :return: 响应给客户端的错误页面
    '''
    bgs = ['bg1.jpg', 'bg2.jpg']
    bg = f'/static/{random.choice(bgs)}'
    render = lambda m : flask.render_template('error.html', message=m, shot=bg)
    resp = flask.make_response(render(msg), code)
    return resp

def render(page, rows, code=200):
    '''
    用来渲染页面

    :param page: html 文件名
    :param rows: 传给 html 的变量
    :param code: http 状态码
    :return: 响应给客户端的正常页面
    '''
    ren = flask.render_template(page, rows=rows)
    resp = flask.make_response(ren, code)
    return resp

@app.route('/', methods=['get'])
def index():
    # 首次运行初始化
    global db_inited
    if not db_inited:
        init_db(weapon_db)
        db_inited = True

    # 实际只有 id 有注入
    s_id   = flask.request.args.get('id')
    s_name = flask.request.args.get('name')
    s_page = flask.request.args.get('p')

    # 分页
    per_page = 4
    try:
        page_no = int(s_page) if s_page is not None else 1
    except Exception:
        page_no = 1
    page_no = max(1, min(2, page_no))
    offset_count = (page_no - 1) * per_page

    # 过 waf 检测
    ri, si = waf_check(s_id)
    rn, sn = waf_check(s_name)

    if not ri or not rn:
        err = error(f'waf detect')
        # err = error(f'waf detect: {si or sn}')
        return err

    # 输入白名单，id 仅数字，name 任意
    safe_id = bool(s_id and re.fullmatch(r'[+-]?\d+', s_id))
    safe_name = bool(s_name and re.fullmatch(r'[-\w\u4e00-\u9fa5\s]+', s_name))

    base_sql = 'SELECT id, name, image FROM weapons'
    where, args = [], []

    if safe_id:
        where.append('id = ?')
        args.append(s_id)

    if safe_name:
        where.append('instr(name, ?) > 0')
        args.append(s_name)

    # WHERE id = ?
    # WHERE id = ? OR instr(name, ?) > 0
    sql = base_sql + (' WHERE ' + ' OR '.join(where) if where else '')

    order_parts = []
    if s_id and not safe_id:
        # 用于把 id 直接拼到 ORDER BY
        order_parts.append(s_id)

    order = 'id asc' if len(order_parts) == 0 else ','.join(order_parts)

    # 避免奇怪输入导致错误
    if re.fullmatch(r'\s*[+-]?\d+\s*', order or ''):
        order = 'id asc'

    # 最终执行的 sql 语句
    # SELECT id, name, image
    # FROM weapons
    # WHERE id = ? OR instr(name, ?) > 0
    # ORDER BY id asc   <== CASE WHEN (SELECT 1) THEN id ELSE -id END
    # LIMIT 4 OFFSET 0
    sql = sql + ' ORDER BY ' + order + ' LIMIT ? OFFSET ?'
    args.extend([per_page, offset_count])

    # 如果 sql 执行错误全部走 error.html
    try:
        rows = select_rows(sql, tuple(args), weapon_db)
    except Exception:
        return error('query error')

    flask.g.page_no = page_no
    flask.g.total_pages = 2
    return render(index_page, rows)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=27001)


